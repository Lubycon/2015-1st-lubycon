$(function()//Language dropdown menu start
{
    var lang_parent = $('#kor_lang');
	var lang_parent_dl = $('.lang_kor');
    var lang_child = $('#all_lang');
    var lang_all = $('#lang');
    var lang_list = $('.lang_all');

    lang_child.ready(function()
    {
        lang_child.hide();						
    });

    lang_parent.mouseenter(function()
    {
        lang_child.stop().slideDown(300);
    });

    lang_all.mouseleave(function()
    {
        lang_child.stop().slideUp(300);
    });

    lang_list.hover(function()
    {
        $(this).css('color','#fff')
    },
    function()
    {
        $(this).css('color','#929292')
    });
    
    lang_list.click(function()
    {
        lang_parent_dl.text($(this).text());
		lang_child.slideUp(300);
	});
});//Language dropdown menu end





$(function()//Top Menu 1 start
{
    var menu_sldn1 = $('#menu_sldn1');
    var slli_li = $('.slli_li');
    var con_1 = $('.con_1');

    menu_sldn1.ready(function()
    {
        menu_sldn1.hide();						
    });
    
    con_1.mouseenter(function()
    {
        menu_sldn1.fadeIn(100);
    });
    
    menu_sldn1.mouseleave(function()
    {
        menu_sldn1.fadeOut(100);
    });
	
    slli_li.hover(function()
    {
        $(this).css('background','#ffbe54')
    },
    function()
    {
        $(this).css('background','#464646')
    });
	
	});//Top Menu 1 end
$(function()//Top Menu 2 start
{
    var menu_sldn2 = $('#menu_sldn2');
    var slli_li = $('.slli_li');
    var con_2 = $('.con_2');

    menu_sldn2.ready(function()
    {
        menu_sldn2.hide();						
    });
    
    con_2.mouseenter(function()
    {
        menu_sldn2.fadeIn(100);
    });
    
    menu_sldn2.mouseleave(function()
    {
        menu_sldn2.fadeOut(100);
    });
	
    slli_li.hover(function()
    {
        $(this).css('background','#ffbe54')
    },
    function()
    {
        $(this).css('background','#464646')
    });
	
	});//Top Menu 2 end
$(function()//Top Menu 3 start
{
    var menu_sldn3 = $('#menu_sldn3');
    var slli_li = $('.slli_li');
    var con_3 = $('.con_3');

    menu_sldn3.ready(function()
    {
        menu_sldn3.hide();						
    });
    
    con_3.mouseenter(function()
    {
        menu_sldn3.fadeIn(100);
    });
    
    menu_sldn3.mouseleave(function()
    {
        menu_sldn3.fadeOut(100);
    });
	
    slli_li.hover(function()
    {
        $(this).css('background','#ffbe54')
    },
    function()
    {
        $(this).css('background','#464646')
    });
	
	});//Top Menu 3 end



$(function(){	//sign in micro window start
	var signin_miwi	= $('#signin_miwi');
	var signin_ul = $('#signin_ul');
	var i = false;
	
	signin_ul.ready(function(){
	signin_miwi.hide();
	});
	
	signin_ul.click(function(){
		
	if( i == false){;
		signin_miwi.show();
		i = true;
	}
	else if(i == true)
	{
		signin_miwi.hide();
		i = false;
	};
	});
});	//sign in micro window start


$(function(){ //filler start
	var mid_con = $('.mid_con');
	var mid_con_first = $('#mid_con_first');
	var mid_con_se = $('#mid_con_se');
	var mid_con_th = $('#mid_con_th');
	var triangle = $('.triangle');
	
	mid_con.ready(function(){
		mid_con_first.addClass('mid_con_clicked');
	});
	
	mid_con.on(
	{
		mouseenter : function() {
		mid_con.removeClass('mid_con_over');
		$(this).addClass('mid_con_over');
	},
		mouseleave : function() {
		mid_con.removeClass('mid_con_out');
		$(this).addClass('mid_con_out');
	},
		click : function() {
		mid_con.removeClass('mid_con_clicked');
		$(this).addClass('mid_con_clicked');
	}
 });
	
	mid_con_first.click(function(){
		triangle.stop().animate({left:303},100);
	});
	mid_con_se.click(function(){
		triangle.stop().animate({left:490},100);
	});
	mid_con_th.click(function(){
		triangle.stop().animate({left:676},100);
	});
}); //fillter end


$(function(){ //sign in btn hover start
var signin = $('#signin_bt')
	
signin.hover(function(){
	$(this).css('background','#ffffff');
	$(this).css('color','#000');
	$(this).css('font-weight','bolder');
	},
    function(){
	$(this).css('background','none');
	$(this).css('color','#fff');
	$(this).css('font-weight','normal');

	});

});//sign in btn hover end


$(function(){  //board category mouse event start
	var board_cate = $('.board_cate');
	var board_cate_first = $('#board_cate_first');
	
	board_cate.ready(function(){
		board_cate_first.addClass('board_cate_clicked');
		
	});
	
	board_cate.on(
	{
		mouseenter : function() {
		board_cate.removeClass('board_cate_over');
		$(this).addClass('board_cate_over');
	},
		mouseleave : function() {
		board_cate.removeClass('board_cate_out');
		$(this).addClass('board_cate_out');
	},
		click : function() {
		board_cate.removeClass('board_cate_clicked');
		$(this).addClass('board_cate_clicked');
	}
 });
}); //board category mouse event start end

$(function(){ //search box click value reset start
	var search_box = $('#search_box');
	
	search_box.focus(function(){
		search_box.val('');
	});
	search_box.blur(function(){				 
		if(search_box.val() == '')
		{
			search_box.val('Enter the keyword');
		}
	});
});		//search box click value reset end

$(function(){ //select box drop down start
	var select_box = $('#selcet_box');
	var selected = $('.search_selected');
	var select_down = $('.select_down');
	var select_down_li = $('.select_down li');
	var i = false;
	
	$(document).ready(function(){
		select_down.hide();
	});
	
	selected.click(function()
	{
	if( i == false){;
		select_down.show();
	i = true;
	}
		else if(i == true)
	{
		select_down.hide();
		i = false;
	};
	});
	
	select_down_li.click(function(){
		selected.text($(this).text());
		select_down.hide();
		i = false;
	});
}); //select box drop down end




$(function(){  //slider img, designer art img mouse over event start
	var slsum_li = $('.slider-items li');
	var btb = $('#bottom_top_bottom li');
	
	slsum_li.hover(function()
	{
		$(this).stop().animate({opacity:0.5},100);
	},
	function()
	{
		$(this).stop().animate({opacity:1},100);
	}
	);
	
	btb.hover(function()
	{
		$(this).stop().animate({opacity:0.5},100);
	},
	function()
	{
		$(this).stop().animate({opacity:1},100);
	}
	);
});	//slider img, designer art img mouse over event end

$(function(){
	var gragh_alt1 = $('#gragh_alt1');
	var gragh_alt2 = $('#gragh_alt2');
	var gragh_alt3 = $('#gragh_alt3');
	var gragh_1 = $('.gragh_1');
	var gragh_2 = $('.gragh_2');
	var gragh_3 = $('.gragh_3');
	
	$(document).ready(function()
	{
		gragh_alt1.hide();
		gragh_alt2.hide();
		gragh_alt3.hide();
	});
	
	gragh_1.hover(function()
	{
		gragh_alt1.fadeIn(100);
	},
	function(){
		gragh_alt1.fadeOut(100);
	});
	gragh_2.hover(function()
	{
		gragh_alt2.fadeIn(100);
	},
	function(){
		gragh_alt2.fadeOut(100);
	});
	gragh_3.hover(function()
	{
		gragh_alt3.fadeIn(100);
	},
	function(){
		gragh_alt3.fadeOut(100);
	});
});

